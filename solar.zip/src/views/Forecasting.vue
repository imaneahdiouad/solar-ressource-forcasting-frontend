<template>
<v-container>
  <v-col cols="12">
    <v-row align="center" justify="center" class="text-h4">
      Geographical Location of study site
    </v-row>
    <v-row>
      <v-col cols="3">
        <v-text-field
          label="Station"
          outlined
        ></v-text-field>
      </v-col>
      <v-col cols="3">
        <v-text-field
          label="Latitude"
          outlined
        ></v-text-field>
      </v-col>
      <v-col cols="3">
        <v-text-field
          label="Longitude"
          outlined
        ></v-text-field>
      </v-col>
      <v-col cols="3">
        <v-text-field
          label="Altitude"
          outlined
        ></v-text-field>
      </v-col>
    </v-row>
  </v-col>
  <v-col cols="12">
    <v-row>
      <v-col cols="5">
          <v-row>
            <v-select
              :items="[]"
              label="Forecasting Horizon"
              outlined
            ></v-select>
          </v-row>
          <v-row>
            <v-btn class="mt-2" block color="primary">Run Forecast</v-btn>
          </v-row>
          <v-row>
            <v-btn class="mt-2" block color="warning">Clear Forecast</v-btn>
          </v-row>
          <v-row>
            <v-col cols="3" class="d-flex justify-center align-center">
              <div class="text-subtitle-1">
                Export Data
              </div>
            </v-col>
            <v-col cols="9">
              <v-file-input label="Browse"></v-file-input>
            </v-col>
          </v-row>
      </v-col>
      <v-col cols="1">
        <v-divider vertical></v-divider>
      </v-col>
      <v-col cols="6">
        2
      </v-col>
    </v-row>
  </v-col>
</v-container>
</template>

<script>
export default {
  name: 'Forecasting'
}
</script>

<style scoped>

</style>
